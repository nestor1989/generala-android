// Genera capturas 1080x1920 para Play Store a partir del juego real (app/src/main/assets/index.html).
const {chromium}=require('playwright');const fs=require('fs');const path=require('path');
const GAME='file://'+path.resolve('app/src/main/assets/index.html');
const FONTS=path.resolve('app/src/main/assets/fonts');
(async()=>{
const b=await chromium.launch();
async function gamePage(seed){
  const p=await b.newPage({viewport:{width:360,height:640},deviceScaleFactor:2});
  await p.addInitScript((seed)=>{
    let a=seed; window.__forced=null;
    const rnd=()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
    Math.random=()=>{ if(window.__forced&&window.__forced.length) return (window.__forced.shift()-1)/6+0.01; return rnd(); };
    const store={}; window.GeneralaNative={loadState:k=>k in store?store[k]:null,saveState:(k,v)=>{if(v==="")delete store[k];else store[k]=v;},
      haptic(){},onGameFinished(){},onPlayAgain(){},isRewardedReady:()=>true,showRewarded:r=>setTimeout(()=>GeneralaApp.onRewardResult(r,true),10),
      hasRemovedAds:()=>false,getRemoveAdsPrice:()=>"",purchaseRemoveAds(){},share(){},isReminderEnabled:()=>true,setReminderEnabled(){},
      isPrivacyOptionsRequired:()=>false,showPrivacyOptions(){},openPrivacyPolicy(){}};
    store.generala_onboarded="1";
  },seed);
  await p.goto(GAME); await p.waitForTimeout(400); return p;
}
async function humanTurn(p){ // tira una vez y anota la mejor casilla
  await p.click('#roll-btn'); await p.waitForTimeout(30);
  const btns=await p.$$('.cell-empty-btn'); let best=null,bv=-1;
  for(const x of btns){const v=+(await x.textContent()); if(v>bv){bv=v;best=x;}}
  await best.click();
}
async function waitHuman(p){ for(let i=0;i<80;i++){ const t=await p.textContent('#turn-name'); if(t.startsWith('Turno')) return; await p.waitForTimeout(150);} }
const shots={};
// 1: Generala servida en partida contra la máquina
{ const p=await gamePage(7); await p.fill('#me-name','Néstor'); await p.fill('#rival-name','Abuela Rosa'); await p.click('#start-btn');
  for(let r=0;r<4;r++){ await humanTurn(p); await waitHuman(p); }
  await p.evaluate(()=>{window.__forced=[5,5,5,5,5];}); await p.click('#roll-btn'); await p.waitForTimeout(500);
  await p.evaluate(()=>window.scrollTo(0,0)); await p.waitForTimeout(150); shots.s1=await p.screenshot(); await p.close(); }
// 2: tutorial, las jugadas
{ const p=await gamePage(3); await p.click('#replay-onboarding'); for(let i=0;i<3;i++) await p.click('#ob-next'); await p.waitForTimeout(200);
  shots.s2=await p.screenshot(); await p.close(); }
// 3: pasar el teléfono con nombres
{ const p=await gamePage(5); await p.click('#mode-pass'); await p.click('#inc-players'); await p.click('#inc-players');
  const n=['Mamá','Tío Carlos','Sofi','Néstor']; for(let i=0;i<4;i++) await p.fill('#name-input-'+i,n[i]);
  await p.evaluate(()=>{document.activeElement.blur();window.scrollTo(0,120);}); await p.waitForTimeout(150);
  shots.s3=await p.screenshot(); await p.close(); }
// 4: tirada con dados guardados (mitad de turno) mostrando planilla
{ const p=await gamePage(11); await p.fill('#me-name','Néstor'); await p.fill('#rival-name','Don Tito'); await p.click('#start-btn');
  for(let r=0;r<3;r++){ await humanTurn(p); await waitHuman(p); }
  await p.evaluate(()=>{window.__forced=[6,6,2,6,4];}); await p.click('#roll-btn'); await p.waitForTimeout(400);
  for(const i of [0,1,3]) await p.click('#dice-row .die:nth-child('+(i+1)+')'); await p.waitForTimeout(200);
  await p.evaluate(()=>window.scrollTo(0,0)); await p.waitForTimeout(150); shots.s4=await p.screenshot(); await p.close(); }
fs.mkdirSync('store-listing/_raw',{recursive:true});
for(const k in shots) fs.writeFileSync('store-listing/_raw/'+k+'.png',shots[k]);
await b.close();})();
