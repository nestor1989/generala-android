// Arma las capturas finales (1080x1920) y los banners (1024x500) para Play Store.
const {chromium}=require('playwright');const fs=require('fs');const path=require('path');
const F=path.resolve('app/src/main/assets/fonts');
const b64=f=>fs.readFileSync(path.join(F,f)).toString('base64');
const faces=`@font-face{font-family:Fraunces;font-weight:600;src:url(data:font/woff2;base64,${b64('fraunces-latin-600-normal.woff2')})}
@font-face{font-family:Fraunces;font-weight:700;src:url(data:font/woff2;base64,${b64('fraunces-latin-700-normal.woff2')})}
@font-face{font-family:Karla;font-weight:500;src:url(data:font/woff2;base64,${b64('karla-latin-500-normal.woff2')})}
@font-face{font-family:Karla;font-weight:700;src:url(data:font/woff2;base64,${b64('karla-latin-700-normal.woff2')})}`;
const bg='radial-gradient(120% 80% at 50% 0%, #145039, #0F3D2E 55%, #0A241B)';
const SHOTS=[['s1','¡Generala servida!','Cinco iguales de una: 100 puntos'],
             ['s4','Guardá los que quieras','Hasta 3 tiradas por turno'],
             ['s3','Pasá el teléfono','De 2 a 4 jugadores en la misma mesa'],
             ['s2','¿No sabés jugar?','Te lo enseñamos en un minuto']];
const BANNERS={es:'El clásico de 5 dados. Contra la máquina o en la mesa.',en:'The classic 5-dice game. Play the computer or pass the phone.',
  pt:'O clássico General de 5 dados. Contra o celular ou na mesa.',fr:'Le classique à 5 dés, façon Yams. Seul ou à plusieurs.',
  de:'Der Würfelklassiker mit 5 Würfeln. Allein oder am Tisch.',it:'Il classico con 5 dadi. Da solo o in compagnia.'};
const die=(n,s)=>{const P={1:[5],2:[1,9],3:[1,5,9],4:[1,3,7,9],5:[1,3,5,7,9],6:[1,3,4,6,7,9]}[n];
  return `<div style="width:${s}px;height:${s}px;border-radius:${s*.2}px;background:#FDFBF3;box-shadow:0 ${s*.08}px 0 #A8641A;display:grid;grid-template:repeat(3,1fr)/repeat(3,1fr);padding:${s*.15}px;box-sizing:border-box">${[1,2,3,4,5,6,7,8,9].map(i=>`<span style="place-self:center;width:${s*.17}px;height:${s*.17}px;border-radius:50%;background:${P.includes(i)?'#241F14':'transparent'}"></span>`).join('')}</div>`;};
(async()=>{const b=await chromium.launch();const p=await b.newPage();
fs.mkdirSync('store-listing/screenshots/es',{recursive:true});fs.mkdirSync('store-listing/banner',{recursive:true});
await p.setViewportSize({width:1080,height:1920});
for(let i=0;i<SHOTS.length;i++){const [k,t,sub]=SHOTS[i];const img='data:image/png;base64,'+fs.readFileSync(`store-listing/_raw/${k}.png`).toString('base64');
 await p.setContent(`<style>${faces}body{margin:0;width:1080px;height:1920px;background:${bg};overflow:hidden;font-family:Karla}</style>
 <div style="padding:120px 80px 0;text-align:center;color:#F6EFDC">
  <div style="font-family:Fraunces;font-weight:700;font-size:92px;line-height:1.05">${t}</div>
  <div style="margin-top:22px;font-size:46px;font-weight:500;color:#E8D9AE">${sub}</div></div>
 <div style="position:absolute;left:50%;top:470px;transform:translateX(-50%);width:800px;height:1422px;border-radius:64px;background:#081b14;padding:18px;box-shadow:0 40px 80px -20px rgba(0,0,0,.6)">
  <img src="${img}" style="width:800px;height:1422px;object-fit:cover;object-position:top;border-radius:48px;display:block"></div>`);
 await p.waitForTimeout(250);await p.screenshot({path:`store-listing/screenshots/es/es_${i+1}_${k}.png`});}
await p.setViewportSize({width:1024,height:500});
for(const [lang,tag] of Object.entries(BANNERS)){
 await p.setContent(`<style>${faces}body{margin:0;width:1024px;height:500px;background:${bg};overflow:hidden;font-family:Karla;display:flex;align-items:center;gap:40px;padding:0 70px;box-sizing:border-box}</style>
 <div style="flex:1;color:#F6EFDC"><div style="font-family:Fraunces;font-weight:700;font-size:104px;line-height:1">Generala</div>
 <div style="margin-top:18px;font-size:32px;font-weight:500;color:#E8D9AE;line-height:1.3;max-width:470px">${tag}</div></div>
 <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:22px;width:360px;transform:rotate(-6deg)">${[5,5,5,5,5].map(n=>die(n,104)).join('')}</div>`);
 await p.waitForTimeout(250);await p.screenshot({path:`store-listing/banner/feature_graphic_${lang}.png`});}
await b.close();})();
