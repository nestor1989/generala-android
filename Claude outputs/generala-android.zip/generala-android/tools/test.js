const {chromium}=require('playwright');
(async()=>{
 const b=await chromium.launch();
 const ctx=await b.newContext({viewport:{width:390,height:820}});
 const p=await ctx.newPage();
 const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
 await p.addInitScript(()=>{
   const store={}; window.__log=[];
   window.GeneralaNative={
     loadState:k=>k in store?store[k]:null, saveState:(k,v)=>{ if(v==="") delete store[k]; else store[k]=v; },
     haptic:k=>__log.push('haptic:'+k), onGameFinished:w=>__log.push('finished:'+w), onPlayAgain:()=>__log.push('again'),
     isRewardedReady:()=>true, showRewarded:r=>{__log.push('rewarded:'+r); setTimeout(()=>GeneralaApp.onRewardResult(r,true),50)},
     hasRemovedAds:()=>false, getRemoveAdsPrice:()=>"ARS 1.999", purchaseRemoveAds:()=>__log.push('buy'),
     share:t=>__log.push('share:'+t), isReminderEnabled:()=>false, setReminderEnabled:v=>__log.push('rem:'+v), openPrivacyPolicy:()=>__log.push('priv')};
   window.__store=store;
 });
 await p.goto('file://'+process.cwd()+'/android/app/src/main/assets/index.html');
 await p.waitForTimeout(300);
 const fontOk = await p.evaluate(()=>document.fonts.check("16px Fraunces"));
 await p.click('#ob-skip');
 await p.screenshot({path:'/tmp/t1.png'});
 await p.fill('#me-name','Néstor');
 await p.click('#start-btn');
 for(let i=0;i<3;i++){await p.click('#roll-btn');await p.waitForTimeout(80);}
 console.log('extra visible', await p.isVisible('#extra-roll-btn'));
 await p.click('#extra-roll-btn');await p.waitForTimeout(200);
 console.log('rolls', await p.textContent('#roll-count'), 'rollBtn disabled', await p.isDisabled('#roll-btn'));
 await p.click('#roll-btn');await p.waitForTimeout(100);
 // pick a zero cell
 const zero = await p.$('.cell-empty-btn:not(.can-score)');
 await zero.click(); await p.waitForTimeout(200);
 console.log('undo visible', await p.isVisible('#undo-bar'));
 await p.screenshot({path:'/tmp/t2.png'});
 await p.click('#undo-btn'); await p.waitForTimeout(300);
 console.log('after undo turn:', await p.textContent('#turn-name'), await p.textContent('#roll-count'));
 // play whole game quickly: human always picks first button
 const T0=Date.now(); for(let t=0;Date.now()-T0<150000;t++){
   if(await p.isVisible('#screen-results')) break;
   const who = await p.textContent('#turn-name');
   if(who.startsWith('Turno')){
     if((await p.textContent('#roll-count')).startsWith('0/')) { await p.click('#roll-btn'); await p.waitForTimeout(30); }
     const c = await p.$('.cell-empty-btn.can-score') || await p.$('.cell-empty-btn');
     if(c) await c.click();
   }
   await p.waitForTimeout(150);
 }
 console.log('results visible', await p.isVisible('#screen-results'), await p.textContent('#winner-title'));
 await p.screenshot({path:'/tmp/t3.png'});
 await p.click('#share-btn');
 await p.click('#again-btn');
 console.log('resume hidden', await p.isHidden('#resume-btn'));
 // resume test
 await p.click('#start-btn'); await p.click('#roll-btn');
 const back = await p.evaluate(()=>GeneralaApp.onBack());
 console.log('back handled', back, 'resume text', await p.textContent('#resume-btn'));
 await p.screenshot({path:'/tmp/t4.png'});
 await p.click('#resume-btn');
 console.log('resumed rolls', await p.textContent('#roll-count'));
 console.log('back at setup ->', await p.evaluate(()=>{GeneralaApp.onBack(); return GeneralaApp.onBack();}));
 console.log('log', (await p.evaluate(()=>__log)).filter(x=>!x.startsWith('haptic')).join(' | ').slice(0,400));
 console.log('font', fontOk, 'errors', errs);
 await b.close();})();
