import re
s=open('_caza/index.html',encoding='utf-8').read()
s=s[s.index('<title>'):s.rindex('</body>')]
R=[
('Cazapalabras — Privacidad','Generala — Privacidad'),
('com.nestordelrio.cazapalabras','com.nestordelrio.generala'),
('22 de septiembre de 2026','24 de septiembre de 2026'),('September 22, 2026','September 24, 2026'),('22 de setembro de 2026','24 de setembro de 2026'),
('Tu progreso (racha, puntajes, palabras encontradas) se guarda solo en tu propio celular, nunca en un servidor nuestro.',
 'La partida en curso y los nombres que escribís para los jugadores se guardan solo en tu propio celular, nunca en un servidor nuestro.'),
('Your progress (streak, scores, words found) is saved only on your own phone, never on a server of ours.',
 'Your game in progress and the player names you type are saved only on your own phone, never on a server of ours.'),
('Seu progresso (sequência, pontuações, palavras encontradas) fica salvo só no seu próprio celular, nunca em um servidor nosso.',
 'A partida em andamento e os nomes de jogadores que você digita ficam salvos só no seu próprio celular, nunca em um servidor nosso.'),
('Cazapalabras (Word Search) doesn','Generala doesn'),('O Cazapalabras (Caça-Palavras) não','O Generala não'),
('<b>Cazapalabras</b> (disponible como «Cazapalabras: Sopa de Letras», «Cazapalabras: Word Search» y «Cazapalabras: Caça-Palavras» según el mercado), el juego de sopa de letras para Android',
 '<b>Generala</b> (en algunas tiendas figura con nombres como «Generala: Juego de Dados» o «Yatzy y Generala: Dados»), el juego de dados para Android'),
('<b>Cazapalabras</b> (listed as "Cazapalabras: Word Search", "Cazapalabras: Sopa de Letras" or "Cazapalabras: Caça-Palavras" depending on the store), the Android word search game',
 '<b>Generala</b> (listed under names such as "Generala: Classic Dice Game" or "Generala: Juego de Dados" depending on the store), the Android dice game'),
('o <b>Cazapalabras</b> (listado como "Cazapalabras: Caça-Palavras", "Cazapalabras: Word Search" ou "Cazapalabras: Sopa de Letras", dependendo da loja), o jogo de caça-palavras para Android',
 'o <b>Generala</b> (listado com nomes como "Generala: Jogo de Dados", dependendo da loja), o jogo de dados para Android'),
('Lo único que se guarda es tu progreso de juego — racha de días, mejor puntaje, palabra más larga encontrada, total de palabras y el idioma elegido — y se guarda',
 'Lo único que se guarda es lo necesario para jugar — la partida en curso (para retomarla), los nombres que escribas para los jugadores, si activaste el recordatorio diario, si compraste «Sin anuncios» y cuántas partidas jugaste (para espaciar los anuncios) — y se guarda'),
('Ese progreso nunca se envía a nosotros ni a ningún servidor: si desinstalás la app, se borra.',
 'Esos datos nunca se envían a nosotros ni a ningún servidor propio. Si tenés activada la copia de seguridad de Android, el sistema puede incluirlos en tu copia personal de Google; si desinstalás la app, se borran del teléfono.'),
("The only thing saved is your game progress — daily streak, best score, longest word found, total words, and your chosen language — and it's saved",
 "The only things saved are what the game needs — your game in progress (so you can resume it), the player names you type, whether you turned on the daily reminder, whether you bought \"Remove ads\", and how many games you've played (to space out ads) — and they're saved"),
('That progress is never sent to us or to any server: uninstalling the app deletes it.',
 'This data is never sent to us or to any server of ours. If Android backup is on, the system may include it in your personal Google backup; uninstalling the app deletes it from the phone.'),
('A única coisa salva é o seu progresso no jogo — sequência de dias, melhor pontuação, palavra mais longa encontrada, total de palavras e o idioma escolhido — e isso é salvo',
 'Só é salvo o que o jogo precisa — a partida em andamento (para retomá-la), os nomes de jogadores que você digitar, se você ativou o lembrete diário, se comprou "Sem anúncios" e quantas partidas jogou (para espaçar os anúncios) — e isso é salvo'),
('Esse progresso nunca é enviado para nós nem para nenhum servidor: se você desinstalar o app, ele é apagado.',
 'Esses dados nunca são enviados para nós nem para nenhum servidor próprio. Se o backup do Android estiver ativado, o sistema pode incluí-los no seu backup pessoal do Google; se você desinstalar o app, eles são apagados do celular.'),
('<code>VIBRATE</code> (retroalimentación háptica al tocar las fichas) y <code>POST_NOTIFICATIONS</code> (para el recordatorio diario de racha,',
 '<code>VIBRATE</code> (vibración al tocar y tirar los dados) y <code>POST_NOTIFICATIONS</code> (para el recordatorio diario opcional,'),
('<code>VIBRATE</code> (haptic feedback when tapping tiles), and <code>POST_NOTIFICATIONS</code> (for the daily streak reminder,',
 '<code>VIBRATE</code> (vibration when tapping and rolling dice), and <code>POST_NOTIFICATIONS</code> (for the optional daily reminder,'),
('<code>VIBRATE</code> (retorno tátil ao tocar nas peças) e <code>POST_NOTIFICATIONS</code> (para o lembrete diário de sequência,',
 '<code>VIBRATE</code> (vibração ao tocar e lançar os dados) e <code>POST_NOTIFICATIONS</code> (para o lembrete diário opcional,'),
('La app pide solo tres permisos de Android:','La app pide estos permisos de Android:'),
('The app asks for only three Android permissions:','The app asks for these Android permissions:'),
('O app pede apenas três permissões do Android:','O app pede estas permissões do Android:'),
('es un juego de audiencia general (sopa de letras)','es un juego de dados de audiencia general, sin dinero real ni apuestas'),
('is a general-audience word search game','is a general-audience dice game with no real money or gambling'),
('é um jogo de caça-palavras para público geral','é um jogo de dados para público geral, sem dinheiro real nem apostas'),
('Your game progress lives on your device','Your game data lives on your device'),
('Tu progreso de juego vive en tu dispositivo','Tus datos de juego viven en tu dispositivo'),
('Seu progresso no jogo fica no seu aparelho','Seus dados de jogo ficam no seu aparelho'),
('desinstalar la app para borrar tu progreso local','desinstalar la app para borrar tus datos locales'),
('uninstall the app to delete your local progress','uninstall the app to delete your local data'),
('desinstalar o app para apagar seu progresso local','desinstalar o app para apagar seus dados locais'),
]
miss=[a[:50] for a,b in R if a not in s]
print("missing:",miss)
for a,b in R: s=s.replace(a,b)
s=s.replace("Cazapalabras\\' real implementation","Generala\\'s real implementation").replace('Cazapalabras','Generala')
ins={
'<h2><span class="num">4.</span>Consentimiento':'<h2><span class="num">3b.</span>Compra de «Sin anuncios»</h2>\n    <p>La compra única «Sin anuncios» se procesa íntegramente por <b>Google Play</b>. Nosotros no recibimos tu tarjeta ni tus datos de pago: la app solo recibe de Google Play la confirmación de que la compra existe, para quitar los anuncios entre partidas. Aplica la <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Política de Privacidad de Google</a>.</p>\n\n    <h2><span class="num">4.</span>Consentimiento',
'<h2><span class="num">4.</span>Ad consent':'<h2><span class="num">3b.</span>"Remove ads" purchase</h2>\n    <p>The one-time "Remove ads" purchase is processed entirely by <b>Google Play</b>. We never receive your card or payment details: the app only gets confirmation from Google Play that the purchase exists, so it can remove ads between games. <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Google\'s Privacy Policy</a> applies.</p>\n\n    <h2><span class="num">4.</span>Ad consent',
'<h2><span class="num">4.</span>Consentimento':'<h2><span class="num">3b.</span>Compra de "Sem anúncios"</h2>\n    <p>A compra única "Sem anúncios" é processada inteiramente pelo <b>Google Play</b>. Nós não recebemos seu cartão nem seus dados de pagamento: o app só recebe do Google Play a confirmação de que a compra existe, para remover os anúncios entre partidas. Vale a <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Política de Privacidade do Google</a>.</p>\n\n    <h2><span class="num">4.</span>Consentimento',
}
for a,b in ins.items():
    assert s.count(a)==1,a; s=s.replace(a,b)
open('privacy.html','w',encoding='utf-8').write(s)
print(re.findall(r'.{40}(?:sopa de letras|word search|caça-palavras|fichas|racha|streak|tiles|palabras).{40}', s, re.I))
