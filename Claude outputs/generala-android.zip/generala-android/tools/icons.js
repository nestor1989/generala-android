const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const p=await b.newPage();
const svg=fs.readFileSync('store/icon.svg','utf8');
async function shot(size,out,round){await p.setViewportSize({width:size,height:size});
 // legacy icons: full-bleed square cropped from the 108 grid (inner 72 = visible area) scaled
 await p.setContent(`<html><body style="margin:0;background:transparent"><div style="width:${size}px;height:${size}px;overflow:hidden;${out==='store'?'':(round?'border-radius:50%;':'border-radius:'+(size*0.18)+'px;')}"><svg viewBox="${out==='store'?'0 0 108 108':'18 18 72 72'}" width="${size}" height="${size}">${svg.replace(/<svg[^>]*>|<\/svg>/g,'')}</svg></div></body></html>`);
 await p.screenshot({path:out==='store'?'store/icon-512.png':out,omitBackground:true});}
await shot(512,'store',false);
const d={mdpi:48,hdpi:72,xhdpi:96,xxhdpi:144,xxxhdpi:192};
for(const [k,v] of Object.entries(d)){const dir=`android/app/src/main/res/mipmap-${k}`;fs.mkdirSync(dir,{recursive:true});
 await shot(v,`${dir}/ic_launcher.png`,false);await shot(v,`${dir}/ic_launcher_round.png`,true);}
await b.close();})();
